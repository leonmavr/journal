def foo_bar():
    pass