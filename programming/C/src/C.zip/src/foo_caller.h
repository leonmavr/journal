#ifndef FOO_CALLER_H
#define FOO_CALLER_H 

void foo_caller(void);

#endif /* FOO_CALLER_H */
