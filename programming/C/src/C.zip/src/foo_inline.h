#ifndef FOO_INLINE_H
#define FOO_INLINE_H 
inline unsigned int foo(void)
{
	return 0xaa;
}
#endif /* FOO_INLINE_H */
