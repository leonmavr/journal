inline int foo()
{
	return 0xaa;
}

int main(int argc, char *argv[])
{
	int ret;
	
	ret = foo();
	return 0;
}
