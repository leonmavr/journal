#ifndef FOO_H
#define FOO_H 

#include <stdio.h>

unsigned int foo(void)
{
	return 0xaa;
}
#endif /* FOO_H */
